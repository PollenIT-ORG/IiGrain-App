import { createAsyncThunk } from '@reduxjs/toolkit';
import * as notificationApi from '../../api/notificationApi';
import type { GetNotificationsParams } from '../../api/notificationApi';
import type { NotificationsPage } from '../../types/notification';
import { handleApiError, StandardizedError } from '../../utils/handleApiError';

type ThunkConfig = { rejectValue: StandardizedError };

export const fetchNotificationsThunk = createAsyncThunk<
  NotificationsPage,
  GetNotificationsParams | undefined,
  ThunkConfig
>('notifications/fetch', async (params, { rejectWithValue }) => {
  try {
    return await notificationApi.getNotifications(params);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchMoreNotificationsThunk = createAsyncThunk<
  NotificationsPage,
  number,
  ThunkConfig
>('notifications/fetchMore', async (page, { rejectWithValue }) => {
  try {
    return await notificationApi.getNotifications({ page });
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchUnreadCountThunk = createAsyncThunk<number, void, ThunkConfig>(
  'notifications/fetchUnreadCount',
  async (_arg, { rejectWithValue }) => {
    try {
      return await notificationApi.getUnreadCount();
    } catch (error) {
      return rejectWithValue(handleApiError(error));
    }
  },
);

export const markNotificationReadThunk = createAsyncThunk<
  { id: string; unreadCount: number },
  string,
  ThunkConfig
>('notifications/markRead', async (id, { rejectWithValue }) => {
  try {
    const unreadCount = await notificationApi.markNotificationRead(id);
    return { id, unreadCount };
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const markAllNotificationsReadThunk = createAsyncThunk<
  { updated: number; unreadCount: number },
  void,
  ThunkConfig
>('notifications/markAllRead', async (_arg, { rejectWithValue }) => {
  try {
    return await notificationApi.markAllNotificationsRead();
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});
