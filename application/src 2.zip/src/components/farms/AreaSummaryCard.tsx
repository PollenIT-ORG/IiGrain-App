import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { AppIcon } from '../AppIcon';
import {
  COLORS,
  borderRadius,
  borderWidth,
  presets,
  shadows,
  spacing,
} from '../../constants';
import { formatNumber, moderateScale, scale } from '../../utils';
import AppText from '../AppText/AppText';
import AppGradient from '../AppGradient/AppGradient';

export interface AreaSummaryCardProps {
  total: number;
  used: number;
  available: number;
}

const LR_START = { x: 0, y: 0 };
const LR_END = { x: 1, y: 0 };

const Stat: React.FC<{ label: string; value: number; color: string }> = ({
  label,
  value,
  color,
}) => (
  <View style={styles.stat}>
    <View style={styles.statTop}>
      <View style={[styles.dot, { backgroundColor: color }]} />
      <AppText style={styles.statValue} numberOfLines={1}>
        {formatNumber(value)} ac
      </AppText>
    </View>
    <AppText style={styles.statLabel}>{label}</AppText>
  </View>
);

const AreaSummaryCard: React.FC<AreaSummaryCardProps> = ({ total, used, available }) => {
  const pct = total > 0 ? Math.min(100, Math.max(0, Math.round((used / total) * 100))) : 0;

  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(anim, { toValue: pct, duration: 900, useNativeDriver: false }).start();
  }, [anim, pct]);
  const width = anim.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
    extrapolate: 'clamp',
  });

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <View style={styles.iconWrap}>
          <AppIcon name="vector-square" size={moderateScale(18)} color={COLORS.primary} />
        </View>
        <AppText style={styles.title}>Land Enrolled</AppText>
        <AppText style={styles.pct}>{pct}%</AppText>
      </View>

      <View style={styles.track}>
        <Animated.View style={[styles.fillWrap, { width }]}>
          <AppGradient
            variant="progress"
            start={LR_START}
            end={LR_END}
            style={StyleSheet.absoluteFillObject}
          />
        </Animated.View>
      </View>
      <AppText style={styles.caption}>
        {formatNumber(used)} of {formatNumber(total)} ac used
      </AppText>

      <View style={styles.legendRow}>
        <Stat label="Total" value={total} color={COLORS.gray500} />
        <Stat label="Used" value={used} color={COLORS.primary} />
        <Stat label="Available" value={available} color={COLORS.success} />
      </View>
    </View>
  );
};

export default React.memo(AreaSummaryCard);

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.white,
    borderWidth: borderWidth.thin,
    borderColor: COLORS.gray200,
    borderRadius: borderRadius.xl,
    padding: spacing[4],
    gap: spacing[2],
    ...shadows.sm,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing[2] },
  iconWrap: {
    width: scale(34),
    height: scale(34),
    borderRadius: borderRadius.md,
    backgroundColor: COLORS.lightPrimary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { ...presets.labelLG, color: COLORS.gray900, flex: 1 },
  pct: { ...presets.headingSM, color: COLORS.primary },
  track: {
    height: scale(10),
    borderRadius: borderRadius.full,
    backgroundColor: COLORS.gray200,
    overflow: 'hidden',
    marginTop: spacing[1],
  },
  fillWrap: { height: '100%', borderRadius: borderRadius.full, overflow: 'hidden' },
  caption: { ...presets.bodyXS, color: COLORS.gray600 },
  legendRow: { flexDirection: 'row', marginTop: spacing[2], gap: spacing[2] },
  stat: { flex: 1, gap: spacing[1] },
  statTop: { flexDirection: 'row', alignItems: 'center', gap: spacing[1.5] },
  dot: { width: scale(8), height: scale(8), borderRadius: borderRadius.full },
  statValue: { ...presets.labelMD, color: COLORS.gray900, flexShrink: 1 },
  statLabel: { ...presets.bodyXS, color: COLORS.gray600 },
});
