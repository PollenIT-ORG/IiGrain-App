import { createAsyncThunk } from '@reduxjs/toolkit';
import * as assessmentApi from '../../api/assessmentApi';
import type {
  AssessmentQuestionDetail,
  AssessmentReview,
  AssessmentSubmitResult,
  CategoryQuestionList,
  FieldAssessmentSummary,
  FieldRegenIndex,
  MyAssessmentsOverview,
  SaveAnswerInput,
  SavedAnswer,
} from '../../types/assessment';
import type { MyAssessmentHistory } from '../../api/assessmentApi';
import { handleApiError, StandardizedError } from '../../utils/handleApiError';

type ThunkConfig = { rejectValue: StandardizedError };

export interface FieldScopeArg {
  programId: string;
  fieldId: string;
}

export interface CategoryQuestionsArg {
  programId: string;
  fieldId: string;
  categoryId: string;
}

export interface QuestionDetailArg {
  programId: string;
  fieldId: string;
  categoryId: string;
  questionId: string;
}

export interface SaveAnswerArg {
  programId: string;
  fieldId: string;
  questionId: string;
  input: SaveAnswerInput;
}

export const fetchAssessmentSummaryThunk = createAsyncThunk<
  FieldAssessmentSummary,
  FieldScopeArg,
  ThunkConfig
>('assessment/fetchSummary', async ({ programId, fieldId }, { rejectWithValue }) => {
  try {
    return await assessmentApi.getAssessmentSummary(programId, fieldId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const refreshAssessmentSummaryThunk = createAsyncThunk<
  FieldAssessmentSummary,
  FieldScopeArg,
  ThunkConfig
>('assessment/refreshSummary', async ({ programId, fieldId }, { rejectWithValue }) => {
  try {
    return await assessmentApi.getAssessmentSummary(programId, fieldId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchCategoryQuestionsThunk = createAsyncThunk<
  CategoryQuestionList,
  CategoryQuestionsArg,
  ThunkConfig
>('assessment/fetchCategoryQuestions', async ({ programId, fieldId, categoryId }, { rejectWithValue }) => {
  try {
    return await assessmentApi.getCategoryQuestions(programId, fieldId, categoryId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchQuestionDetailThunk = createAsyncThunk<
  AssessmentQuestionDetail,
  QuestionDetailArg,
  ThunkConfig
>('assessment/fetchQuestionDetail', async ({ programId, fieldId, categoryId, questionId }, { rejectWithValue }) => {
  try {
    return await assessmentApi.getQuestionDetail(programId, fieldId, categoryId, questionId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const saveAssessmentAnswerThunk = createAsyncThunk<
  SavedAnswer,
  SaveAnswerArg,
  ThunkConfig
>('assessment/saveAnswer', async ({ programId, fieldId, questionId, input }, { rejectWithValue }) => {
  try {
    return await assessmentApi.saveAnswer(programId, fieldId, questionId, input);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchAssessmentReviewThunk = createAsyncThunk<
  AssessmentReview,
  FieldScopeArg,
  ThunkConfig
>('assessment/fetchReview', async ({ programId, fieldId }, { rejectWithValue }) => {
  try {
    return await assessmentApi.getAssessmentReview(programId, fieldId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const submitAssessmentThunk = createAsyncThunk<
  AssessmentSubmitResult,
  FieldScopeArg,
  ThunkConfig
>(
  'assessment/submit',
  async ({ programId, fieldId }, { rejectWithValue }) => {
    try {
      return await assessmentApi.submitAssessment(programId, fieldId);
    } catch (error) {
      return rejectWithValue(handleApiError(error));
    }
  },
  {
    condition: (_arg, { getState }) => {
      const state = getState() as { assessment: { submitting: boolean } };
      return !state.assessment.submitting;
    },
  },
);

export const fetchMyAssessmentFieldsThunk = createAsyncThunk<
  MyAssessmentsOverview,
  void,
  ThunkConfig
>('assessment/myFields', async (_arg, { rejectWithValue }) => {
  try {
    return await assessmentApi.getMyAssessmentFields();
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchMyAssessmentHistoryThunk = createAsyncThunk<
  MyAssessmentHistory,
  string | undefined,
  ThunkConfig
>('assessment/myHistory', async (farmId, { rejectWithValue }) => {
  try {
    return await assessmentApi.getMyAssessmentHistory(farmId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const fetchFieldRegenIndexThunk = createAsyncThunk<
  FieldRegenIndex,
  FieldScopeArg,
  ThunkConfig
>('assessment/fetchRegenIndex', async ({ programId, fieldId }, { rejectWithValue }) => {
  try {
    return await assessmentApi.getFieldRegenIndex(programId, fieldId);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});
