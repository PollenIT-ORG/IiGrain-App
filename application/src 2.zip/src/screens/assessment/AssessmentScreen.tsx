import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import {
  useFocusEffect,
  useNavigation,
  useRoute,
  type NavigationProp,
  type RouteProp,
} from '@react-navigation/native';
import { AppIcon, ICONS } from '../../components/AppIcon';
import { AnimatedTabBar, AppHeader, AppText, Button, TabItem } from '../../components';
import {
  AppShimmer,
  AppShimmerButton,
  AppShimmerCard,
  AppShimmerChip,
  AppShimmerList,
  AppShimmerText,
} from '../../components/Shimmer';
import { EmptyState } from '../../components/farms';
import AssessmentFieldCard from '../../components/assessment/AssessmentFieldCard';
import EmptyAssessmentState from '../../components/assessment/EmptyAssessmentState';
import AssessmentSummaryCard from '../../components/assessment/AssessmentSummaryCard';
import FieldRegenIndexCard from '../../components/assessment/FieldRegenIndexCard';
import CategoryProgressList from '../../components/assessment/CategoryProgressList';
import SectionHeader from '../../components/assessment/SectionHeader';
import { COLORS, borderRadius, spacing } from '../../constants';
import { moderateScale, scale } from '../../utils';
import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import {
  fetchAssessmentSummaryThunk,
  refreshAssessmentSummaryThunk,
  fetchMyAssessmentFieldsThunk,
  fetchMyAssessmentHistoryThunk,
  fetchFieldRegenIndexThunk,
  selectAnswerVersion,
  selectAssessmentCategories,
  selectAssessmentError,
  selectAssessmentRefreshing,
  selectAssessmentSummary,
  selectFieldRegenIndex,
  selectRegenIndexLoading,
  selectLoadedSummaryScope,
  selectLoadedRegenScope,
  selectMyAssessments,
  selectMyFieldsLoading,
  selectMyHistoryCount,
  selectMyHistoryLoading,
  selectMyHistoryRaw,
} from '../../redux/slices/assessmentSlice';
import { selectResumePoint } from '../../redux/slices/assessmentProgressSlice';
import type { AssessmentCategory, MyAssessmentField } from '../../types/assessment';
import type {
  AppStackParamList,
  AppTabParamList,
} from '../../navigation/navigationTypes';
import { isAssessmentComplete, toCategoryItems, toSummaryCardModel } from './assessmentPresenter';
import { styles } from './AssessmentScreenStyle';

type AssessmentTab = 'myassessment' | 'history';

const TABS: TabItem<AssessmentTab>[] = [
  { key: 'myassessment', label: 'My Assessment' },
  { key: 'history', label: 'History' },
];

const AssessmentScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp<AppStackParamList>>();
  const route = useRoute<RouteProp<AppTabParamList, 'Assessment'>>();
  const dispatch = useAppDispatch();

  const myAssessments = useAppSelector(selectMyAssessments);
  const myFieldsLoading = useAppSelector(selectMyFieldsLoading);

  const historyItems = useAppSelector(selectMyHistoryRaw);
  const historyCount = useAppSelector(selectMyHistoryCount);
  const historyLoading = useAppSelector(selectMyHistoryLoading);

  const summary = useAppSelector(selectAssessmentSummary);
  const categories = useAppSelector(selectAssessmentCategories);
  const refreshing = useAppSelector(selectAssessmentRefreshing);
  const error = useAppSelector(selectAssessmentError);

  const regenIndex = useAppSelector(selectFieldRegenIndex);
  const regenIndexLoading = useAppSelector(selectRegenIndexLoading);
  const loadedSummaryScope = useAppSelector(selectLoadedSummaryScope);
  const loadedRegenScope = useAppSelector(selectLoadedRegenScope);
  const answerVersion = useAppSelector(selectAnswerVersion);

  const [activeTab, setActiveTab] = useState<AssessmentTab>('myassessment');
  const [selected, setSelected] = useState<{ fieldId: string; programId: string } | undefined>(
    route.params?.fieldId && route.params?.programId
      ? { fieldId: route.params.fieldId, programId: route.params.programId }
      : undefined,
  );
  const selScope = selected ? `${selected.programId}:${selected.fieldId}` : undefined;

  useEffect(() => {
    dispatch(fetchMyAssessmentFieldsThunk());
    dispatch(fetchMyAssessmentHistoryThunk(undefined));
  }, [dispatch]);

  useEffect(() => {
    if (route.params?.fieldId && route.params?.programId) {
      setSelected({ fieldId: route.params.fieldId, programId: route.params.programId });
      navigation.setParams({ fieldId: undefined, programId: undefined });
    }
  }, [route.params?.fieldId, route.params?.programId, navigation]);

  const summaryReady = !!summary && !!selScope && loadedSummaryScope === selScope;
  useEffect(() => {
    if (selected && !summaryReady) {
      dispatch(fetchAssessmentSummaryThunk(selected));
    }
  }, [dispatch, selected, summaryReady]);

  const regenReady = !!regenIndex && !!selScope && loadedRegenScope === selScope;
  useEffect(() => {
    if (selected && !regenReady) {
      dispatch(fetchFieldRegenIndexThunk(selected));
    }
  }, [dispatch, selected, regenReady]);

  const isFirstFocus = useRef(true);
  useFocusEffect(
    useCallback(() => {
      if (isFirstFocus.current) {
        isFirstFocus.current = false;
        return;
      }
      dispatch(fetchMyAssessmentFieldsThunk());
      dispatch(fetchMyAssessmentHistoryThunk(undefined));
      if (selected) {
        dispatch(fetchAssessmentSummaryThunk(selected));
        dispatch(fetchFieldRegenIndexThunk(selected));
      }
    }, [dispatch, selected]),
  );

  // Redux-driven safety net: fires the moment an answer is saved anywhere in the
  // app (not gated on navigation focus events), so data is already fresh by the
  // time the user navigates back here.
  const lastSyncedAnswerVersion = useRef(answerVersion);
  useEffect(() => {
    if (answerVersion === lastSyncedAnswerVersion.current) {
      return;
    }
    lastSyncedAnswerVersion.current = answerVersion;
    dispatch(fetchMyAssessmentFieldsThunk());
    dispatch(fetchMyAssessmentHistoryThunk(undefined));
    if (selected) {
      dispatch(fetchAssessmentSummaryThunk(selected));
      dispatch(fetchFieldRegenIndexThunk(selected));
    }
  }, [answerVersion, dispatch, selected]);

  const handleTabChange = useCallback((tab: AssessmentTab) => setActiveTab(tab), []);

  const onSelectField = useCallback(
    (item: MyAssessmentField) =>
      setSelected({ fieldId: item.fieldId, programId: item.programId }),
    [],
  );
  const onBackToList = useCallback(() => setSelected(undefined), []);
  const onRefreshList = useCallback(
    () => dispatch(fetchMyAssessmentFieldsThunk()),
    [dispatch],
  );

  const onRefreshSummary = useCallback(() => {
    if (selected) {
      dispatch(refreshAssessmentSummaryThunk(selected));
    }
  }, [dispatch, selected]);

  const onRetrySummary = useCallback(() => {
    if (selected) {
      dispatch(fetchAssessmentSummaryThunk(selected));
    }
  }, [dispatch, selected]);

  const onOpenHistory = useCallback(
    (item: MyAssessmentField) => {
      navigation.navigate('AssessmentReview', {
        programId: item.programId,
        fieldId: item.fieldId,
        locked: true,
      });
    },
    [navigation],
  );

  const summaryCard = useMemo(
    () => (summary ? toSummaryCardModel(summary) : null),
    [summary],
  );
  const categoryItems = useMemo(() => toCategoryItems(categories), [categories]);

  const handleCategoryPress = useCallback(
    (category: AssessmentCategory) => {
      if (!selected) {
        return;
      }
      navigation.navigate('AssessmentCategory', {
        programId: selected.programId,
        fieldId: selected.fieldId,
        categoryId: category.id,
        categoryName: category.title,
      });
    },
    [navigation, selected],
  );

  const isComplete = useMemo(
    () => (summary ? isAssessmentComplete(summary) : false),
    [summary],
  );

  const resumePoint = useAppSelector(
    selectResumePoint(selected?.programId, selected?.fieldId),
  );

  const handlePrimaryCta = useCallback(() => {
    if (!selected) {
      return;
    }
    if (isComplete) {
      navigation.navigate('AssessmentReview', {
        programId: selected.programId,
        fieldId: selected.fieldId,
      });
      return;
    }
    if (resumePoint) {
      const savedCat = categories.find(c => c.id === resumePoint.categoryId);
      if (savedCat && savedCat.answered < savedCat.totalQuestions) {
        navigation.navigate('AssessmentQuestionDetail', {
          programId: selected.programId,
          fieldId: selected.fieldId,
          categoryId: savedCat.id,
          questionId: resumePoint.questionId,
        });
        return;
      }
    }
    const target = categories.find(c => c.answered < c.totalQuestions) ?? categories[0];
    if (target) {
      navigation.navigate('AssessmentCategory', {
        programId: selected.programId,
        fieldId: selected.fieldId,
        categoryId: target.id,
        categoryName: target.name,
      });
    }
  }, [selected, isComplete, navigation, categories, resumePoint]);

  const renderCount = (label: string, value: number, color: string) => (
    <View style={styles.countChip}>
      <AppText style={[styles.countValue, { color }]}>{value}</AppText>
      <AppText style={styles.countLabel}>{label}</AppText>
    </View>
  );

  const renderFieldCardSkeleton = (key: number) => (
    <AppShimmerCard key={key} style={skStyles.cardGap}>
      <View style={skStyles.rowGap}>
        <AppShimmer width={scale(40)} height={scale(40)} radius={borderRadius.md} />
        <View style={skStyles.rowBody}>
          <AppShimmerText width="60%" height={moderateScale(14)} />
          <AppShimmerText width="40%" height={moderateScale(11)} />
        </View>
        <AppShimmerChip width={scale(72)} />
      </View>
      <AppShimmer width="100%" height={scale(8)} radius={borderRadius.full} />
      <AppShimmerText width={scale(90)} height={moderateScale(11)} />
    </AppShimmerCard>
  );

  const renderListSkeleton = () => (
    <View style={styles.body}>
      <View style={styles.landingHeader}>
        <AppShimmerText width="55%" height={moderateScale(18)} />
        <AppShimmerText width={scale(56)} height={moderateScale(11)} />
      </View>
      <View style={styles.countsRow}>
        {[0, 1, 2 ,4].map(i => (
          <View key={i} style={styles.countChip}>
            <AppShimmer width={scale(28)} height={moderateScale(20)} />
            <AppShimmerText width="70%" height={moderateScale(10)} />
          </View>
        ))}
      </View>
      {[0, 1, 2 , 3].map(i => renderFieldCardSkeleton(i))}
    </View>
  );

  const renderSummarySkeleton = () => (
    <View style={styles.body}>
      <View style={styles.backRow}>
        <AppShimmer width={scale(20)} height={scale(20)} radius={borderRadius.full} />
        <AppShimmerText width={scale(120)} height={moderateScale(12)} />
      </View>
      <AppShimmerText width="60%" height={moderateScale(12)} />

      <AppShimmerCard style={skStyles.cardGap}>
        <View style={skStyles.titleRow}>
          <AppShimmerText width="55%" height={moderateScale(16)} />
          <AppShimmerChip width={scale(80)} />
        </View>
        <AppShimmerText width="45%" height={moderateScale(11)} />
        <AppShimmerText width={scale(120)} height={moderateScale(20)} />
        <AppShimmer width="100%" height={scale(8)} radius={borderRadius.full} />
        <AppShimmerButton />
      </AppShimmerCard>

      <View style={styles.section}>
        <AppShimmerText width={scale(120)} height={moderateScale(14)} />
        <View style={styles.categoriesCard}>
          <AppShimmerList
            count={4}
            renderItem={() => (
              <View style={skStyles.categoryRow}>
                <AppShimmer width={scale(36)} height={scale(36)} radius={borderRadius.md} />
                <View style={skStyles.rowBody}>
                  <AppShimmerText width="55%" height={moderateScale(13)} />
                  <AppShimmer width="100%" height={scale(6)} radius={borderRadius.full} />
                </View>
              </View>
            )}
          />
        </View>
      </View>
    </View>
  );

  const renderError = (message: string, onRetry: () => void) => (
    <View style={styles.stateCenter}>
      <AppIcon name={ICONS.ERROR} size={moderateScale(48)} color={COLORS.gray500} />
      <AppText style={styles.stateTitle}>Couldn't load</AppText>
      <AppText style={styles.stateMessage}>{message}</AppText>
      <Button title="Retry" onPress={onRetry} fullWidth={false} style={styles.retryBtn} />
    </View>
  );

  const renderFieldList = () => {
    if (myFieldsLoading && !myAssessments) {
      return renderListSkeleton();
    }
    if (error && !myAssessments) {
      return renderError(error, onRefreshList);
    }
    const data = myAssessments;
    if (!data) {
      return renderListSkeleton();
    }
    return (
      <ScrollView
        contentContainerStyle={styles.body}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={myFieldsLoading && !!myAssessments}
            onRefresh={onRefreshList}
            colors={[COLORS.primary]}
            tintColor={COLORS.primary}
          />
        }>
        <View style={styles.landingHeader}>
          <AppText style={styles.landingTitle}>{data.title || 'My Assessments'}</AppText>
          <AppText style={styles.landingCount}>
            {data.counts.total} field{data.counts.total === 1 ? '' : 's'}
          </AppText>
        </View>

        <View style={styles.countsRow}>
          {renderCount('In Progress', data.counts.inProgress, COLORS.primary)}
          {renderCount('Completed', historyCount, COLORS.success)}
          {renderCount('Not Started', data.counts.notStarted, COLORS.gray500)}
        </View>

        {data.fields.length > 0 ? (
          data.fields.map(f => (
            <AssessmentFieldCard
              key={`${f.fieldId}:${f.programId}`}
              item={f}
              onPress={onSelectField}
            />
          ))
        ) : (
          <EmptyState
            icon="clipboard-text-outline"
            title="No fields to assess"
            message="Add a field to your farm to start an assessment."
          />
        )}
      </ScrollView>
    );
  };

  const renderFieldSummary = () => {
    if (error && !summaryReady) {
      return renderError(error, onRetrySummary);
    }
    if (!summary || !summaryCard || !summaryReady) {
      return renderSummarySkeleton();
    }
    return (
      <ScrollView
        contentContainerStyle={styles.body}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefreshSummary}
            colors={[COLORS.primary]}
            tintColor={COLORS.primary}
          />
        }>
        <Pressable onPress={onBackToList} style={styles.backRow} hitSlop={8}>
          <AppIcon name={ICONS.CHEVRON_LEFT} size={moderateScale(20)} color={COLORS.primary} />
          <AppText style={styles.backText}>All assessments</AppText>
        </Pressable>

        <AppText style={styles.fieldCaption}>
          {summary.field.name} · {summary.field.farmName}
        </AppText>

        <AssessmentSummaryCard summary={summaryCard} onContinue={handlePrimaryCta} />

        <View style={styles.section}>
          <SectionHeader title="Categories" />
          {categoryItems.length > 0 ? (
            <View style={styles.categoriesCard}>
              <CategoryProgressList
                categories={categoryItems}
                onCategoryPress={handleCategoryPress}
              />
            </View>
          ) : (
            <EmptyState
              icon="clipboard-text-outline"
              title="No categories yet"
              message="This assessment has no categories to show."
            />
          )}
        </View>

        <FieldRegenIndexCard
          data={regenReady ? regenIndex : null}
          loading={regenIndexLoading}
        />
      </ScrollView>
    );
  };

  const onRefreshHistory = useCallback(
    () => dispatch(fetchMyAssessmentHistoryThunk(undefined)),
    [dispatch],
  );

  const renderHistory = () => {
    if (!historyItems) {
      return error ? renderError(error, onRefreshHistory) : renderListSkeleton();
    }
    if (historyItems.length === 0) {
      return (
        <ScrollView
          contentContainerStyle={styles.body}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={historyLoading && !!historyItems}
              onRefresh={onRefreshHistory}
              colors={[COLORS.primary]}
              tintColor={COLORS.primary}
            />
          }>
          <EmptyAssessmentState
            icon="clipboard-check-outline"
            title="No History Yet"
            message="Completed assessments will appear here once you submit your first evaluation."
          />
        </ScrollView>
      );
    }
    return (
      <ScrollView
        contentContainerStyle={styles.body}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={historyLoading && !!historyItems}
            onRefresh={onRefreshHistory}
            colors={[COLORS.primary]}
            tintColor={COLORS.primary}
          />
        }>
        {historyItems.map(f => (
          <AssessmentFieldCard
            key={`${f.fieldId}:${f.programId}`}
            item={f}
            onPress={onOpenHistory}
          />
        ))}
      </ScrollView>
    );
  };




  
  const renderMyAssessment = () =>
    selected ? renderFieldSummary() : renderFieldList();

  return (
    <View style={styles.safe}>
      <AppHeader variant="title" title="Assessments" showDrawer rightActions={['add']} />

      <AnimatedTabBar
        tabs={TABS}
        activeKey={activeTab}
        onTabChange={handleTabChange}
        style={styles.tabBar}
      />

      {activeTab === 'myassessment' ? renderMyAssessment() : renderHistory()}
    </View>
  );
};

export default AssessmentScreen;

const skStyles = StyleSheet.create({
  cardGap: { gap: spacing[3] },
  rowGap: { flexDirection: 'row', alignItems: 'center', gap: spacing[3] },
  rowBody: { flex: 1, gap: spacing[1.5] },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing[2],
  },
  categoryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing[3],
    paddingVertical: spacing[3],
  },
});
