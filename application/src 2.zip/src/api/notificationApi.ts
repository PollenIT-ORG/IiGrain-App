import http from '../services/http';
import { Endpoints } from '../config/endpoints';
import type { AppNotification, NotificationsPage } from '../types/notification';

interface Envelope<T> {
  data: T;
  meta?: { page: number; limit: number; total: number; totalPages: number };
}

interface RawNotification {
  id: string;
  type: string;
  title: string;
  body: string | null;
  data: Record<string, unknown> | null;
  read: boolean;
  read_at: string | null;
  created_at: string;
}

interface RawNotificationsPayload {
  unreadCount: number;
  notifications: RawNotification[];
}

interface RawUnreadCountPayload {
  count: number;
}

interface RawMarkReadPayload {
  unreadCount: number;
}

interface RawMarkAllReadPayload {
  updated: number;
  unreadCount: number;
}

const mapNotification = (raw: RawNotification): AppNotification => ({
  id: raw.id,
  type: raw.type,
  title: raw.title ?? '',
  body: raw.body,
  data: raw.data ?? {},
  read: !!raw.read,
  readAtISO: raw.read_at,
  createdAtISO: raw.created_at,
});

export interface GetNotificationsParams {
  page?: number;
  limit?: number;
  unreadOnly?: boolean;
}

export const getNotifications = async (
  params?: GetNotificationsParams,
): Promise<NotificationsPage> => {
  const res = await http.get<Envelope<RawNotificationsPayload>>(Endpoints.notifications.list, {
    params: {
      page: params?.page ?? 1,
      limit: params?.limit ?? 20,
      unreadOnly: params?.unreadOnly ? 'true' : undefined,
    },
  });
  const payload = res.data.data;
  const meta = res.data.meta;
  return {
    notifications: (payload.notifications ?? []).map(mapNotification),
    unreadCount: payload.unreadCount ?? 0,
    page: meta?.page ?? params?.page ?? 1,
    totalPages: meta?.totalPages ?? 1,
    total: meta?.total ?? payload.notifications?.length ?? 0,
  };
};

export const getUnreadCount = async (): Promise<number> => {
  const res = await http.get<Envelope<RawUnreadCountPayload>>(
    Endpoints.notifications.unreadCount,
  );
  return res.data.data.count ?? 0;
};

export const markNotificationRead = async (id: string): Promise<number> => {
  const res = await http.patch<Envelope<RawMarkReadPayload>>(Endpoints.notifications.markRead(id));
  return res.data.data.unreadCount ?? 0;
};

export const markAllNotificationsRead = async (): Promise<RawMarkAllReadPayload> => {
  const res = await http.patch<Envelope<RawMarkAllReadPayload>>(
    Endpoints.notifications.markAllRead,
  );
  return res.data.data;
};

export { mapNotification };
export type { RawNotification };
