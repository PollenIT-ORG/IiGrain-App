export type NotificationType =
  | 'new_program_available'
  | 'enrolled_in_program'
  | 'assessor_assigned'
  | 'assessor_visit_started'
  | 'assessment_submitted'
  | string;

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string | null;
  data: Record<string, unknown>;
  read: boolean;
  readAtISO: string | null;
  createdAtISO: string;
}

export interface NotificationsPage {
  notifications: AppNotification[];
  unreadCount: number;
  page: number;
  totalPages: number;
  total: number;
}
