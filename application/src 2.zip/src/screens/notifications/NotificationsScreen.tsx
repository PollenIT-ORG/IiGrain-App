import React, { useCallback, useEffect } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, View } from 'react-native';
import { AppIcon, ICONS } from '../../components/AppIcon';
import { AppHeader, AppText, Button } from '../../components';
import { AppShimmerRow } from '../../components/Shimmer';
import { EmptyState } from '../../components/farms';
import { COLORS } from '../../constants';
import { addAlpha, moderateScale, scale } from '../../utils';
import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import {
  fetchNotificationsThunk,
  fetchMoreNotificationsThunk,
  markNotificationReadThunk,
  markAllNotificationsReadThunk,
  selectNotificationsRaw,
  selectUnreadCount,
  selectHasMoreNotifications,
  selectNotificationsLoading,
  selectNotificationsRefreshing,
  selectNotificationsLoadingMore,
  selectNotificationsError,
  selectMarkingAllNotifications,
  selectNotificationsPage,
} from '../../redux/slices/notificationSlice';
import { metaForNotificationType, formatRelativeTime } from './notificationPresenter';
import type { AppNotification } from '../../types/notification';
import { styles } from './NotificationsScreenStyle';

const NotificationsScreen: React.FC = () => {
  const dispatch = useAppDispatch();

  const items = useAppSelector(selectNotificationsRaw);
  const unreadCount = useAppSelector(selectUnreadCount);
  const loading = useAppSelector(selectNotificationsLoading);
  const refreshing = useAppSelector(selectNotificationsRefreshing);
  const loadingMore = useAppSelector(selectNotificationsLoadingMore);
  const hasMore = useAppSelector(selectHasMoreNotifications);
  const page = useAppSelector(selectNotificationsPage);
  const error = useAppSelector(selectNotificationsError);
  const markingAll = useAppSelector(selectMarkingAllNotifications);

  useEffect(() => {
    dispatch(fetchNotificationsThunk({ page: 1 }));
  }, [dispatch]);

  const onRefresh = useCallback(() => {
    dispatch(fetchNotificationsThunk({ page: 1 }));
  }, [dispatch]);

  const onRetry = useCallback(() => {
    dispatch(fetchNotificationsThunk({ page: 1 }));
  }, [dispatch]);

  const onEndReached = useCallback(() => {
    if (!loadingMore && hasMore) {
      dispatch(fetchMoreNotificationsThunk(page + 1));
    }
  }, [dispatch, loadingMore, hasMore, page]);

  const onPressItem = useCallback(
    (item: AppNotification) => {
      if (!item.read) {
        dispatch(markNotificationReadThunk(item.id));
      }
    },
    [dispatch],
  );

  const onMarkAllRead = useCallback(() => {
    dispatch(markAllNotificationsReadThunk());
  }, [dispatch]);

  const renderItem = useCallback(
    ({ item }: { item: AppNotification }) => {
      const meta = metaForNotificationType(item.type);
      return (
        <Pressable
          onPress={() => onPressItem(item)}
          accessibilityRole="button"
          accessibilityLabel={item.title}
          style={({ pressed }) => [
            styles.card,
            !item.read && styles.cardUnread,
            pressed && styles.cardPressed,
          ]}>
          <View style={[styles.iconCircle, { backgroundColor: addAlpha(meta.color, 0.12) }]}>
            <AppIcon name={meta.icon} size={moderateScale(20)} color={meta.color} />
          </View>
          <View style={styles.textCol}>
            <View style={styles.titleRow}>
              <AppText
                style={[styles.title, !item.read && styles.titleUnread]}
                numberOfLines={1}>
                {item.title}
              </AppText>
              {!item.read ? <View style={styles.dot} /> : null}
            </View>
            {item.body ? (
              <AppText style={styles.message} numberOfLines={2}>
                {item.body}
              </AppText>
            ) : null}
            <AppText style={styles.time}>{formatRelativeTime(item.createdAtISO)}</AppText>
          </View>
        </Pressable>
      );
    },
    [onPressItem],
  );

  const renderSkeleton = () => (
    <View style={styles.body}>
      {[0, 1, 2, 3, 4, 5].map(i => (
        <AppShimmerRow key={i} showLeading leadingSize={scale(44)} lines={2} style={styles.card} />
      ))}
    </View>
  );

  const renderEmpty = () => (
    <EmptyState
      icon="bell-outline"
      title="No notifications yet"
      message="We'll let you know here when there's something new — programs, assessments, and visits."
    />
  );

  const renderError = () => (
    <View style={styles.stateCenter}>
      <AppIcon name={ICONS.ERROR} size={moderateScale(48)} color={COLORS.gray500} />
      <AppText style={styles.stateTitle}>Couldn't load notifications</AppText>
      <AppText style={styles.stateMessage}>{error}</AppText>
      <Button title="Retry" onPress={onRetry} fullWidth={false} style={styles.retryBtn} />
    </View>
  );

  const renderFooter = () =>
    loadingMore ? (
      <View style={styles.footerLoader}>
        <ActivityIndicator color={COLORS.primary} />
      </View>
    ) : null;

  const showSkeleton = loading && items === null;
  const showError = !!error && items === null;

  return (
    <View style={styles.safe}>
      <AppHeader variant="back" title="Notifications" />

      {unreadCount > 0 ? (
        <View style={styles.toolbar}>
          <AppText style={styles.toolbarText}>
            {unreadCount} unread notification{unreadCount === 1 ? '' : 's'}
          </AppText>
          <Pressable
            onPress={onMarkAllRead}
            disabled={markingAll}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel="Mark all as read"
            style={styles.markAllBtn}>
            <AppText style={styles.markAllText}>Mark all read</AppText>
          </Pressable>
        </View>
      ) : null}

      {showSkeleton ? (
        renderSkeleton()
      ) : showError ? (
        renderError()
      ) : (
        <FlatList
          data={items ?? []}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.body}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[COLORS.primary]}
              tintColor={COLORS.primary}
            />
          }
          onEndReachedThreshold={0.4}
          onEndReached={onEndReached}
          ListEmptyComponent={renderEmpty}
          ListFooterComponent={renderFooter}
        />
      )}
    </View>
  );
};

export default NotificationsScreen;
