import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { AppIcon, ICONS } from '../../components/AppIcon';
import { AppHeader, AppText, Button } from '../../components';
import { EmptyState } from '../../components/farms';
import {
  AppShimmer,
  AppShimmerCircle,
  AppShimmerText,
} from '../../components/Shimmer';
import { COLORS,
  borderRadius,
  borderWidth,
  presets,
  shadows,
  spacing, fonts } from '../../constants';
import { addAlpha, formatDate, moderateScale, scale } from '../../utils';
import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import {
  enrollSelfThunk,
  fetchAvailableProgramsThunk,
  fetchEnrollableFieldsThunk,
  selectAvailablePrograms,
  selectEnrollableFields,
  selectEnrolling,
  selectEnrollmentFieldsLoading,
  selectEnrollmentProgramsLoading,
  selectFieldsError,
  selectProgramsError,
} from '../../redux/slices/enrollmentSlice';
import { showSuccess, showToast } from '../../services/toastService';
import type { AppScreenProps } from '../../navigation/navigationTypes';
import type {
  AvailableProgram,
  EnrollableField,
  ProgramField,
} from '../../types/enrollment';

const dateRange = (start: string | null, end: string | null): string | null => {
  if (start && end) {
    return `${formatDate(start)} – ${formatDate(end)}`;
  }
  if (start) {
    return `From ${formatDate(start)}`;
  }
  if (end) {
    return `Until ${formatDate(end)}`;
  }
  return null;
};

const EnrollNowScreen: React.FC<AppScreenProps<'EnrollNow'>> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const programs = useAppSelector(selectAvailablePrograms);
  const fields = useAppSelector(selectEnrollableFields);
  const loadingPrograms = useAppSelector(selectEnrollmentProgramsLoading);
  const loadingFields = useAppSelector(selectEnrollmentFieldsLoading);
  const enrolling = useAppSelector(selectEnrolling);
  const programsError = useAppSelector(selectProgramsError);
  const fieldsError = useAppSelector(selectFieldsError);

  const [selectedProgramId, setSelectedProgramId] = useState<string | null>(null);
  const [selectedFieldIds, setSelectedFieldIds] = useState<string[]>([]);

  const insets = useSafeAreaInsets();

  const loadPrograms = useCallback(() => dispatch(fetchAvailableProgramsThunk()), [dispatch]);
  const loadFields = useCallback(() => dispatch(fetchEnrollableFieldsThunk()), [dispatch]);

  useFocusEffect(
    useCallback(() => {
      loadPrograms();
      loadFields();
    }, [loadPrograms, loadFields]),
  );

  const selectedProgram =
    programs.find(p => p.id === selectedProgramId) ?? null;
  // New backend returns each program's own fields (with a per-field `enrolled`
  // flag). Old backend omits them → fall back to the flat enrollable list.
  const programFields = selectedProgram?.fields ?? [];
  const useProgramFields = programFields.length > 0;
  const alreadyEnrolled = !!selectedProgram?.alreadyEnrolled;

  // Only the user's newly-checked, NOT-already-enrolled fields — this is the exact
  // payload we submit. Kept airtight even if a background refetch flips a selected
  // field to enrolled=true (so an enrolled id can never reach the POST).
  const newFieldIds = selectedFieldIds.filter(
    id => !programFields.some(f => f.id === id && f.enrolled),
  );

  const onSelectProgram = useCallback((id: string) => {
    setSelectedProgramId(id);
    setSelectedFieldIds([]);
  }, []);

  const toggleField = useCallback((id: string) => {
    setSelectedFieldIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id],
    );
  }, []);

  const hasPrograms = programs.length > 0;
  const selectedCount = newFieldIds.length;
  // A not-already-enrolled program that flipped to full via a refetch stops being
  // submittable; an already-enrolled program can always add fields.
  const programSubmittable =
    !!selectedProgram && !(selectedProgram.isFull && !selectedProgram.alreadyEnrolled);
  const canEnroll =
    !!selectedProgramId && programSubmittable && selectedCount > 0 && !enrolling;

  const onEnroll = useCallback(async () => {
    if (!selectedProgramId) {
      return;
    }
    const enrolledSet = new Set(
      (selectedProgram?.fields ?? []).filter(f => f.enrolled).map(f => f.id),
    );
    const fieldIds = selectedFieldIds.filter(id => !enrolledSet.has(id));
    if (fieldIds.length === 0) {
      return;
    }
    const wasEnrolled = !!selectedProgram?.alreadyEnrolled;
    const action = await dispatch(
      enrollSelfThunk({
        programId: selectedProgramId,
        input: { fieldIds },
      }),
    );
    if (enrollSelfThunk.fulfilled.match(action)) {
      showSuccess(
        wasEnrolled
          ? 'Fields added — they can now be assessed.'
          : 'Enrolled successfully — you can now be assessed.',
      );
      // Stay on screen: the slice optimistically flips the enrolled flags, so the
      // just-added fields immediately show as "Enrolled" (checked + locked).
      setSelectedFieldIds([]);
    } else {
      showToast(action.payload?.message ?? 'Could not enroll. Please try again.', {
        type: 'error',
      });
    }
  }, [dispatch, selectedFieldIds, selectedProgram, selectedProgramId]);

  const renderProgram = (p: AvailableProgram) => {
    const selected = p.id === selectedProgramId;
    const range = dateRange(p.startDateISO, p.endDateISO);
    const capacity =
      p.userLimit != null ? `${p.enrolledCount}/${p.userLimit}` : `${p.enrolledCount}`;
    const blocked = p.isFull && !p.alreadyEnrolled;
    return (
      <TouchableOpacity
        key={p.id}
        activeOpacity={blocked ? 1 : 0.85}
        disabled={blocked}
        onPress={() => onSelectProgram(p.id)}
        style={[styles.card, selected && styles.cardSelected, blocked && styles.cardDisabled]}>
        <View style={styles.cardTop}>
          <View style={styles.flex}>
            <View style={styles.titleRow}>
              <AppText style={styles.progName} numberOfLines={1}>{p.name}</AppText>
              {p.code ? (
                <View style={styles.codeChip}>
                  <AppText style={styles.codeText}>{p.code}</AppText>
                </View>
              ) : null}
              {p.alreadyEnrolled ? (
                <View style={styles.enrolledChip}>
                  <AppText style={styles.enrolledChipText}>Enrolled</AppText>
                </View>
              ) : null}
            </View>
            {p.description ? (
              <AppText style={styles.progDesc} numberOfLines={2}>{p.description}</AppText>
            ) : null}
          </View>
          {blocked ? (
            <View style={styles.fullBadge}>
              <AppText style={styles.fullText}>Full</AppText>
            </View>
          ) : (
            <AppIcon
              name={selected ? 'radiobox-marked' : 'radiobox-blank'}
              size={moderateScale(22)}
              color={selected ? COLORS.primary : COLORS.gray500}
            />
          )}
        </View>
        <View style={styles.metaRow}>
          {range ? (
            <View style={styles.metaItem}>
              <AppIcon name={ICONS.CALENDAR_RANGE} size={moderateScale(14)} color={COLORS.gray600} />
              <AppText style={styles.metaText}>{range}</AppText>
            </View>
          ) : null}
          <View style={styles.metaItem}>
            <AppIcon name={ICONS.USERS} size={moderateScale(14)} color={COLORS.gray600} />
            <AppText style={styles.metaText}>{capacity} enrolled</AppText>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderProgramField = (f: ProgramField) => {
    const checked = f.enrolled || selectedFieldIds.includes(f.id);
    return (
      <TouchableOpacity
        key={f.id}
        activeOpacity={f.enrolled ? 1 : 0.85}
        disabled={f.enrolled}
        onPress={() => toggleField(f.id)}
        style={[
          styles.fieldCard,
          f.enrolled ? styles.fieldEnrolled : checked && styles.cardSelected,
        ]}>
        <AppIcon
          name={checked ? 'checkbox-marked' : 'checkbox-blank-outline'}
          size={moderateScale(22)}
          color={f.enrolled ? COLORS.gray500 : checked ? COLORS.primary : COLORS.gray500}
        />
        <View style={styles.flex}>
          <AppText style={styles.fieldName} numberOfLines={1}>{f.name}</AppText>
          <AppText style={styles.fieldMeta} numberOfLines={1}>
            {f.crop || '—'} · {f.farmName}
          </AppText>
        </View>
        {f.enrolled ? (
          <View style={styles.enrolledChip}>
            <AppText style={styles.enrolledChipText}>Enrolled</AppText>
          </View>
        ) : null}
      </TouchableOpacity>
    );
  };

  const renderFlatField = (f: EnrollableField) => {
    const selected = selectedFieldIds.includes(f.id);
    return (
      <TouchableOpacity
        key={f.id}
        activeOpacity={0.85}
        onPress={() => toggleField(f.id)}
        style={[styles.fieldCard, selected && styles.cardSelected]}>
        <AppIcon
          name={selected ? 'checkbox-marked' : 'checkbox-blank-outline'}
          size={moderateScale(22)}
          color={selected ? COLORS.primary : COLORS.gray500}
        />
        <View style={styles.flex}>
          <AppText style={styles.fieldName} numberOfLines={1}>{f.name}</AppText>
          <AppText style={styles.fieldMeta} numberOfLines={1}>
            {f.crop || '—'} · {f.farmName}
          </AppText>
        </View>
      </TouchableOpacity>
    );
  };

  const noFieldsEmptyState = (
    <EmptyState
      icon="sprout-outline"
      title="Add a field to get started"
      message="You don't have any fields yet. Add a field to one of your farms and you'll be able to join an assessment program."
      actionLabel="Go to Farms"
      onAction={() =>
        navigation.navigate('Shell', {
          screen: 'MainTabs',
          params: { screen: 'Farms' },
        })
      }
    />
  );

  const renderFieldsSection = () => {
    if (!selectedProgram) {
      return (
        <View style={styles.selectHint}>
          <AppIcon name="gesture-tap" size={moderateScale(18)} color={COLORS.gray500} />
          <AppText style={styles.muted}>Select a program above to choose fields.</AppText>
        </View>
      );
    }

    if (useProgramFields) {
      const available = programFields.filter(f => !f.enrolled);
      return (
        <>
          {programFields.map(renderProgramField)}
          {available.length === 0 ? (
            <AppText style={styles.allEnrolledNote}>
              All your fields are already enrolled in this program.
            </AppText>
          ) : null}
        </>
      );
    }

    // Fallback (old backend without per-program fields).
    if (loadingFields && fields.length === 0) {
      return <ActivityIndicator color={COLORS.primary} style={styles.sectionLoader} />;
    }
    if (fieldsError && fields.length === 0) {
      return (
        <View style={styles.inlineError}>
          <AppText style={styles.muted}>{fieldsError}</AppText>
          <Button title="Retry" variant="outline" size="sm" fullWidth={false} onPress={loadFields} style={styles.retry} />
        </View>
      );
    }
    if (fields.length === 0) {
      return noFieldsEmptyState;
    }
    return fields.map(renderFlatField);
  };

  const renderBody = () => {
    if (loadingPrograms && !hasPrograms) {
      return (
        <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
          <AppShimmer height={scale(76)} radius={borderRadius.xl} style={styles.loadingHero} />

          <AppShimmer width="45%" height={moderateScale(14)} radius={borderRadius.sm} style={styles.loadingTitle} />
          {[0, 1].map(i => (
            <View key={i} style={styles.card}>
              <View style={styles.cardTop}>
                <View style={styles.flex}>
                  <AppShimmer width="60%" height={moderateScale(14)} radius={borderRadius.sm} />
                  <AppShimmerText count={2} width="90%" lastLineWidth="70%" style={styles.loadingCardDesc} />
                </View>
                <AppShimmerCircle size={moderateScale(22)} />
              </View>
              <View style={styles.metaRow}>
                <AppShimmer width="40%" height={moderateScale(10)} radius={borderRadius.sm} />
                <AppShimmer width="30%" height={moderateScale(10)} radius={borderRadius.sm} />
              </View>
            </View>
          ))}

          <AppShimmer
            width="45%"
            height={moderateScale(14)}
            radius={borderRadius.sm}
            style={[styles.loadingTitle, styles.sectionGap]}
          />
          {[0, 1, 2].map(i => (
            <View key={i} style={styles.fieldCard}>
              <AppShimmerCircle size={moderateScale(22)} />
              <View style={styles.flex}>
                <AppShimmer width="55%" height={moderateScale(12)} radius={borderRadius.sm} />
                <AppShimmer width="75%" height={moderateScale(10)} radius={borderRadius.sm} style={styles.loadingFieldMeta} />
              </View>
            </View>
          ))}
        </ScrollView>
      );
    }
    if (programsError && !hasPrograms) {
      return (
        <View style={styles.center}>
          <AppIcon name={ICONS.ERROR} size={moderateScale(48)} color={COLORS.gray500} />
          <AppText style={styles.stateTitle}>Couldn't load programs</AppText>
          <AppText style={styles.muted}>{programsError}</AppText>
          <Button title="Retry" onPress={loadPrograms} fullWidth={false} style={styles.retryLg} />
        </View>
      );
    }
    if (!hasPrograms) {
      return (
        <View style={styles.center}>
          <EmptyState
            icon="clipboard-text-outline"
            title="No programs available"
            message="There are no programs open for enrollment right now. Please check back later."
            actionLabel="Refresh"
            onAction={loadPrograms}
          />
        </View>
      );
    }
    return (
      <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
        <View style={styles.hero}>
          <View style={styles.heroIcon}>
            <AppIcon name={ICONS.HANDSHAKE} size={moderateScale(22)} color={COLORS.primary} />
          </View>
          <View style={styles.flex}>
            <AppText style={styles.heroTitle}>Join a program to begin</AppText>
            <AppText style={styles.heroText}>
              Pick a program, choose the fields you want assessed, and you're ready to start.
            </AppText>
          </View>
        </View>

        <AppText style={styles.sectionTitle}>Choose a program</AppText>
        {programs.map(renderProgram)}

        <AppText style={[styles.sectionTitle, styles.sectionGap]}>
          {alreadyEnrolled ? 'Add more fields' : 'Select fields'}
          {selectedCount > 0 ? ` (${selectedCount})` : ''}
        </AppText>
        {renderFieldsSection()}
      </ScrollView>
    );
  };

  return (
    <View style={styles.safe}>
      <AppHeader variant="back" title="Enroll Now" onBack={() => navigation.goBack()} />

      {renderBody()}

      {hasPrograms ? (
        <View style={[styles.footer, { paddingBottom: insets.bottom + scale(8) }]}>
          <AppText style={styles.footerHint} numberOfLines={1}>
            {!selectedProgramId
              ? 'Select a program to continue'
              : selectedCount === 0
              ? alreadyEnrolled
                ? 'Select fields to add'
                : 'Select at least one field'
              : `${selectedCount} field${selectedCount === 1 ? '' : 's'} selected`}
          </AppText>
          <Button
            title={alreadyEnrolled ? 'Add Fields' : 'Enroll Now'}
            onPress={onEnroll}
            loading={enrolling}
            disabled={!canEnroll}
            leftIcon={<AppIcon name={ICONS.SUCCESS} size={moderateScale(20)} color={COLORS.white} />}
          />
        </View>
      ) : null}
    </View>
  );
};

export default EnrollNowScreen;

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.white },
  flex: { flex: 1 },
  body: { padding: spacing[4], paddingBottom: spacing[6] },

  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing[6] },
  stateTitle: { ...presets.headingSM, color: COLORS.gray900, marginTop: spacing[4], textAlign: 'center' },
  retryLg: { marginTop: spacing[4], minWidth: moderateScale(180) },

  hero: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing[3],
    backgroundColor: COLORS.lightPrimary,
    borderRadius: borderRadius.xl,
    padding: spacing[4],
    marginBottom: spacing[5],
  },
  heroIcon: {
    width: scale(44), height: scale(44), borderRadius: borderRadius.full,
    backgroundColor: COLORS.white, alignItems: 'center', justifyContent: 'center',
  },
  heroTitle: { ...presets.headingSM, color: COLORS.gray900 },
  heroText: { ...presets.bodyXS, color: COLORS.gray700, marginTop: spacing[0.5] },

  sectionTitle: { ...presets.headingXS, color: COLORS.gray900, marginBottom: spacing[3] },
  sectionGap: { marginTop: spacing[5] },
  loadingHero: { marginBottom: spacing[5] },
  loadingTitle: { marginBottom: spacing[3] },
  loadingCardDesc: { marginTop: spacing[1] },
  loadingFieldMeta: { marginTop: spacing[0.5] },
  sectionLoader: { marginVertical: spacing[6] },
  inlineError: { alignItems: 'center', gap: spacing[2], paddingVertical: spacing[4] },
  muted: { ...presets.bodySM, color: COLORS.gray500, textAlign: 'center' },
  retry: { minWidth: moderateScale(140) },
  selectHint: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing[2], paddingVertical: spacing[6],
  },
  allEnrolledNote: {
    ...presets.bodySM, color: COLORS.gray600, textAlign: 'center', paddingVertical: spacing[3],
  },

  card: {
    backgroundColor: COLORS.white,
    borderRadius: borderRadius.xl,
    borderWidth: borderWidth.medium,
    borderColor: COLORS.gray200,
    padding: spacing[4],
    marginBottom: spacing[3],
    gap: spacing[2],
    ...shadows.sm,
  },
  cardSelected: { borderColor: COLORS.primary, backgroundColor: COLORS.lightPrimaryBg },
  cardDisabled: { opacity: 0.6 },
  cardTop: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing[3] },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing[2], flexShrink: 1, flexWrap: 'wrap' },
  progName: { ...presets.labelLG, color: COLORS.gray900, flexShrink: 1 },
  codeChip: {
    borderRadius: borderRadius.sm, backgroundColor: COLORS.lightPrimary,
    paddingHorizontal: spacing[1.5], paddingVertical: spacing[0.5],
  },
  codeText: { ...presets.caption, fontFamily: fonts.semibold, color: COLORS.primaryDark },
  enrolledChip: {
    borderRadius: borderRadius.full, backgroundColor: addAlpha(COLORS.success, 0.14),
    paddingHorizontal: spacing[2], paddingVertical: spacing[0.5],
  },
  enrolledChipText: { ...presets.caption, fontFamily: fonts.semibold, color: COLORS.success },
  progDesc: { ...presets.bodyXS, color: COLORS.gray600, marginTop: spacing[1] },
  metaRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: spacing[3] },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: spacing[1] },
  metaText: { ...presets.caption, color: COLORS.gray600 },
  fullBadge: {
    borderRadius: borderRadius.full, backgroundColor: addAlpha(COLORS.danger, 0.14),
    paddingHorizontal: spacing[2.5], paddingVertical: spacing[0.5],
  },
  fullText: { ...presets.caption, fontFamily: fonts.semibold, color: COLORS.danger },

  fieldCard: {
    flexDirection: 'row', alignItems: 'center', gap: spacing[3],
    backgroundColor: COLORS.white,
    borderRadius: borderRadius.lg,
    borderWidth: borderWidth.medium,
    borderColor: COLORS.gray200,
    padding: spacing[3.5],
    marginBottom: spacing[2.5],
    ...shadows.xs,
  },
  fieldEnrolled: { backgroundColor: COLORS.gray100, borderColor: COLORS.gray200 },
  fieldName: { ...presets.labelMD, color: COLORS.gray900 },
  fieldMeta: { ...presets.bodyXS, color: COLORS.gray600, marginTop: spacing[0.5] },

  footer: {
    backgroundColor: COLORS.white,
    borderTopWidth: borderWidth.thin,
    borderTopColor: COLORS.gray200,
    paddingHorizontal: spacing[4],
    paddingTop: spacing[3],
    gap: spacing[2],
    ...shadows.lg,
  },
  footerHint: { ...presets.bodyXS, color: COLORS.gray600, textAlign: 'center' },
});
