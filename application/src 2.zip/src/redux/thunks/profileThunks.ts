import { createAsyncThunk } from '@reduxjs/toolkit';
import * as profileApi from '../../api/profileApi';
import type {
  ChangePasswordPayload,
  UpdateProfilePayload,
  UserProfile,
} from '../../api/profileApi';
import type { MediaFile } from '../../types/media';
import { setUser } from '../slices/authSlice';
import { handleApiError, StandardizedError } from '../../utils/handleApiError';

type ThunkConfig = { rejectValue: StandardizedError };

const syncAuthUser = <T extends UserProfile>(
  user: T,
  dispatch: (action: ReturnType<typeof setUser>) => void,
): T => {
  dispatch(setUser(user));
  return user;
};

export const fetchProfileThunk = createAsyncThunk<UserProfile, void, ThunkConfig>(
  'user/fetchProfile',
  async (_, { dispatch, rejectWithValue }) => {
    try {
      return syncAuthUser(await profileApi.getMyProfile(), dispatch);
    } catch (error) {
      return rejectWithValue(handleApiError(error));
    }
  },
);

export const updateProfileThunk = createAsyncThunk<
  UserProfile,
  UpdateProfilePayload,
  ThunkConfig
>('user/updateProfile', async (payload, { dispatch, rejectWithValue }) => {
  try {
    return syncAuthUser(await profileApi.updateMyProfile(payload), dispatch);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});

export const uploadAvatarThunk = createAsyncThunk<UserProfile, MediaFile, ThunkConfig>(
  'user/uploadAvatar',
  async (file, { dispatch, rejectWithValue }) => {
    try {
      return syncAuthUser(await profileApi.uploadMyAvatar(file), dispatch);
    } catch (error) {
      return rejectWithValue(handleApiError(error));
    }
  },
);

export const removeAvatarThunk = createAsyncThunk<UserProfile, void, ThunkConfig>(
  'user/removeAvatar',
  async (_, { dispatch, rejectWithValue }) => {
    try {
      return syncAuthUser(await profileApi.removeMyAvatar(), dispatch);
    } catch (error) {
      return rejectWithValue(handleApiError(error));
    }
  },
);

export const changePasswordThunk = createAsyncThunk<
  void,
  ChangePasswordPayload,
  ThunkConfig
>('user/changePassword', async (payload, { rejectWithValue }) => {
  try {
    await profileApi.changePassword(payload);
  } catch (error) {
    return rejectWithValue(handleApiError(error));
  }
});
