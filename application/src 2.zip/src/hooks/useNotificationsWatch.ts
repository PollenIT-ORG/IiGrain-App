import { useEffect } from 'react';
import { useAppDispatch } from '../redux/hooks';
import { fetchUnreadCountThunk } from '../redux/thunks/notificationThunks';
import { receiveNotification, setUnreadCount } from '../redux/slices/notificationSlice';
import { mapNotification, type RawNotification } from '../api/notificationApi';
import { connectSocket, getSocket } from '../services/socket';

export const useNotificationsWatch = (): void => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    let alive = true;
    dispatch(fetchUnreadCountThunk());

    const onNew = (raw: unknown) => {
      if (alive && raw && typeof raw === 'object') {
        dispatch(receiveNotification(mapNotification(raw as RawNotification)));
      }
    };
    const onUnreadCount = (raw: unknown) => {
      if (alive && raw && typeof raw === 'object' && 'count' in raw) {
        dispatch(setUnreadCount(Number((raw as { count: unknown }).count) || 0));
      }
    };

    connectSocket()
      .then(socket => {
        if (alive) {
          socket.on('notification:new', onNew);
          socket.on('notification:unread_count', onUnreadCount);
        }
      })
      .catch(() => {});

    return () => {
      alive = false;
      const s = getSocket();
      s?.off('notification:new', onNew);
      s?.off('notification:unread_count', onUnreadCount);
    };
  }, [dispatch]);
};
