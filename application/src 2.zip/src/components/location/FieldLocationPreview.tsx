import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  View,
  type GestureResponderEvent,
} from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';
import { COLORS } from '../../constants';
import { MAP_HTML } from './mapHtml';

const MAP_SOURCE = { html: MAP_HTML } as const;
const ORIGIN_WHITELIST = ['*'];

export interface FieldLocationPreviewProps {
  latitude: number;
  longitude: number;
  zoom?: number;
  /** Forwarded to the WebView so a parent ScrollView can freeze/unfreeze while
   *  the user pans the map (native-side, so they fire reliably on iOS). */
  onTouchStart?: (e: GestureResponderEvent) => void;
  onTouchEnd?: (e: GestureResponderEvent) => void;
  onTouchCancel?: (e: GestureResponderEvent) => void;
}

const FieldLocationPreview: React.FC<FieldLocationPreviewProps> = ({
  latitude,
  longitude,
  zoom = 15,
  onTouchStart,
  onTouchEnd,
  onTouchCancel,
}) => {
  const webRef = useRef<WebView<unknown>>(null);
  const [ready, setReady] = useState(false);

  const center = useCallback(() => {
    webRef.current?.injectJavaScript(
      `window.MAP && window.MAP.setCenter(${latitude}, ${longitude}, ${zoom}); true;`,
    );
  }, [latitude, longitude, zoom]);

  const onMessage = useCallback(
    (e: WebViewMessageEvent) => {
      try {
        const msg = JSON.parse(e.nativeEvent.data);
        if (msg.type === 'ready') {
          setReady(true);
          center();
        }
      } catch {
        // ignore malformed webview messages
      }
    },
    [center],
  );

  useEffect(() => {
    if (ready) {
      center();
    }
  }, [ready, center]);

  return (
    <View style={styles.wrap}>
      <WebView<unknown>
        ref={webRef}
        source={MAP_SOURCE}
        originWhitelist={ORIGIN_WHITELIST}
        onMessage={onMessage}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
        onTouchCancel={onTouchCancel}
        javaScriptEnabled
        domStorageEnabled
        cacheEnabled
        startInLoadingState
        renderLoading={() => (
          <View style={styles.loading}>
            <ActivityIndicator color={COLORS.primary} />
          </View>
        )}
        style={styles.web}
      />
    </View>
  );
};

export default React.memo(FieldLocationPreview);

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  web: { flex: 1, backgroundColor: 'transparent' },
  loading: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
